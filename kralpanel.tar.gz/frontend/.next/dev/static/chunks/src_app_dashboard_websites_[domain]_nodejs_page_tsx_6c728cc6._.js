(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_d0cc8108._.js",
  "static/chunks/node_modules_74d091a7._.js"
],
    source: "dynamic"
});
