(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_61a75eff._.js",
  "static/chunks/node_modules_2280ff33._.js"
],
    source: "dynamic"
});
