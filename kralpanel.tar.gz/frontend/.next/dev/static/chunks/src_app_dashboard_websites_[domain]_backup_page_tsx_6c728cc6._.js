(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_237d9496._.js",
  "static/chunks/node_modules_e9794fb3._.js"
],
    source: "dynamic"
});
