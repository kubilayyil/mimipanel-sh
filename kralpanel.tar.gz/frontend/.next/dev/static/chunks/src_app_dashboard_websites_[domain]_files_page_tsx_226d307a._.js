(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_870f42ce._.js",
  "static/chunks/node_modules_24d0a22a._.js"
],
    source: "dynamic"
});
