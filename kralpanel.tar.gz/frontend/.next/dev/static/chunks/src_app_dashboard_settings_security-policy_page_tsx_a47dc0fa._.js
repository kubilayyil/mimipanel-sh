(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_30a868ed._.js",
  "static/chunks/node_modules_b9b12de1._.js"
],
    source: "dynamic"
});
