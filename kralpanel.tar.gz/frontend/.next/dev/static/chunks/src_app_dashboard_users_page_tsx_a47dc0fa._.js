(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_eec3f199._.js",
  "static/chunks/src_477c3c3a._.js"
],
    source: "dynamic"
});
