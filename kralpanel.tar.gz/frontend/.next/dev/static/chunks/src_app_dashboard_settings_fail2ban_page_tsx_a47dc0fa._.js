(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_73384a48._.js",
  "static/chunks/node_modules_d491dfb7._.js"
],
    source: "dynamic"
});
