(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_eaf7530b._.js",
  "static/chunks/node_modules_2f58b94e._.js"
],
    source: "dynamic"
});
