(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_02d06faa._.js",
  "static/chunks/node_modules_9cf5dd28._.js"
],
    source: "dynamic"
});
