(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_dd2c5224._.js",
  "static/chunks/src_477c3c3a._.js"
],
    source: "dynamic"
});
