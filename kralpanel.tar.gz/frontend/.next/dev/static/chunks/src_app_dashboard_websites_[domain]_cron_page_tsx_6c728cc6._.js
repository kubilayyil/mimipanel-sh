(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_758449d8._.js",
  "static/chunks/node_modules_5f7a0645._.js"
],
    source: "dynamic"
});
