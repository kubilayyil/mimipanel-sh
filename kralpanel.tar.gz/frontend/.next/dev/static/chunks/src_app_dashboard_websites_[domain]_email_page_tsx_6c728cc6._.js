(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_6c906894._.js",
  "static/chunks/node_modules_07e9a1de._.js"
],
    source: "dynamic"
});
