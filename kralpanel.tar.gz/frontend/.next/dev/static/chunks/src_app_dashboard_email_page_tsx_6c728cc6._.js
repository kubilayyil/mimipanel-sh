(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_66221b30._.js",
  "static/chunks/src_6567ce4f._.js"
],
    source: "dynamic"
});
