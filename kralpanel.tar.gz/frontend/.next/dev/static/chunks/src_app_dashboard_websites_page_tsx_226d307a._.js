(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_02d06faa._.js",
  "static/chunks/node_modules_bada89c3._.js"
],
    source: "dynamic"
});
