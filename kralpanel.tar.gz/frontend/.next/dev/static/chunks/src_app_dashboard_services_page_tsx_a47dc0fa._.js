(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_704de9dc._.js",
  "static/chunks/src_26a542f0._.js"
],
    source: "dynamic"
});
