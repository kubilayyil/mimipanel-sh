(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_237d9496._.js",
  "static/chunks/node_modules_c09b2ad4._.js"
],
    source: "dynamic"
});
