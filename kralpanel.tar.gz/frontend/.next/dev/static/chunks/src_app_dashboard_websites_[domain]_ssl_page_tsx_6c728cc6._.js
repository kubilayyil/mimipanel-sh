(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_b5317488._.js",
  "static/chunks/node_modules_6c2168f9._.js"
],
    source: "dynamic"
});
