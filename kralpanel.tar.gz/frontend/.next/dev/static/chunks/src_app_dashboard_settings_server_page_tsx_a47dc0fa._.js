(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_63d825cc._.js",
  "static/chunks/node_modules_c0fd3cf6._.js"
],
    source: "dynamic"
});
