(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_c3db7796._.js",
  "static/chunks/node_modules_2031dc47._.js"
],
    source: "dynamic"
});
