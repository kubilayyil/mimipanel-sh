(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_ae46276c._.js",
  "static/chunks/node_modules_fc74cebc._.js"
],
    source: "dynamic"
});
