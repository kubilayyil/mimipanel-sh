(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_26b7fd27._.js",
  "static/chunks/node_modules_d242269c._.js"
],
    source: "dynamic"
});
