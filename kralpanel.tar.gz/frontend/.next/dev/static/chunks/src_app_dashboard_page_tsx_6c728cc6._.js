(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_53502f5b._.js",
  "static/chunks/node_modules_864d0cdf._.js"
],
    source: "dynamic"
});
